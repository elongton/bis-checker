import { Component, OnInit } from "@angular/core";
import { GearService } from "../gear.service";
import { HttpClient } from "@angular/common/http";

interface Player {
  name: string;
  class: string;
  lastSeen: string;
  spec: string;
}

export interface Item {
  id: number;
  name: string;
}

@Component({
  selector: "app-bis-list",
  templateUrl: "./bis-list.component.html",
  styleUrl: "./bis-list.component.css",
})
export class BisListComponent implements OnInit {
  players: Player[] = [];
  classFilter: string = "";
  dummySpecs = ["Spec A", "Spec B", "Spec C"];
  gear: any;
  copied = false;
  constructor(private http: HttpClient, private gearService: GearService) {}

  ngOnInit(): void {
    this.gearService.getLibrary().subscribe((lib) => {
      this.gear = lib;
      console.log(this.gear);
      this.loadPlayers();
      console.log(this.players);
    });
  }

  loadPlayers(): void {
    this.http.get<Player[]>("/api/player").subscribe({
      next: (data) => {
        this.players = data;
        console.log(data);
      },
      error: (err) => console.error("Failed to fetch players:", err),
    });
  }

  get filteredClasses(): string[] {
    const classes = new Set(this.players.map((p) => p.class));
    return Array.from(classes).sort();
  }

  get groupedPlayers(): Record<string, Player[]> {
    const grouped: Record<string, Player[]> = {};

    for (const player of this.players) {
      if (this.classFilter && player.class !== this.classFilter) continue;
      if (!grouped[player.class]) grouped[player.class] = [];
      grouped[player.class].push(player);
    }

    return grouped;
  }

  updateSpec(player: Player, newSpec: string): void {
    this.http
      .patch(`/api/player/${encodeURIComponent(player.name)}/spec`, {
        spec: newSpec,
      })
      .subscribe({
        next: () => {}, // `player.spec` already updated by ngModel
        error: (err) =>
          console.error(`Failed to update spec for ${player.name}:`, err),
      });
  }

  getSpecOptionsForPlayer(player: Player): string[] {
    if (!this.gear) return [];
    const classEntry = this.gear[player.class];
    return classEntry ? Object.keys(classEntry) : [];
  }

  getSoftBisCount(player: Player): number {
    if (!player.spec || !this.gear) return 0;

    const classGear = this.gear[player.class];
    const specGear = classGear?.[player.spec];
    if (!specGear) return 0;

    let count = 0;
    const playerItems = (player as any).items || {};

    for (const slot of Object.keys(specGear)) {
      const bisItems = specGear[slot];
      const playerSlotItems: Item[] = playerItems[slot] || [];

      if (
        playerSlotItems.some((item) =>
          bisItems.some((bis: Item) => bis.id === item.id)
        )
      ) {
        count++;
      }
    }

    return count;
  }

  getHardBisCount(player: Player): number {
    if (!player.spec || !this.gear) return 0;

    const classGear = this.gear[player.class];
    const specGear = classGear?.[player.spec];
    if (!specGear) return 0;

    let count = 0;
    const playerItems = (player as any).items || {};

    for (const slot of Object.keys(specGear)) {
      const bestItem = specGear[slot][0];
      if (!bestItem) continue;

      const playerSlotItems: Item[] = playerItems[slot] || [];
      if (playerSlotItems.some((item) => item.id === bestItem.id)) {
        count++;
      }
    }

    return count;
  }

  sortColumn: "name" | "class" | "lastSeen" | "softBis" | "hardBis" = "name";

  sortDirection: "asc" | "desc" = "asc";

  get filteredPlayers(): Player[] {
    let filtered = this.players;

    if (this.classFilter) {
      filtered = filtered.filter((p) => p.class === this.classFilter);
    }

    return filtered.sort((a, b) => {
      const aVal = this.getSortValue(a);
      const bVal = this.getSortValue(b);
      if (aVal < bVal) return this.sortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return this.sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }

  getSortValue(player: Player): any {
    switch (this.sortColumn) {
      case "lastSeen":
        return new Date(player.lastSeen).getTime();
      case "softBis":
        return this.getSoftBisCount(player);
      case "hardBis":
        return this.getHardBisCount(player);
      case "class":
        return player.class.toLowerCase();
      default:
        return player.name.toLowerCase();
    }
  }

  setSort(column: "name" | "lastSeen" | "softBis" | "hardBis" | "class"): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortColumn = column;
      this.sortDirection = "asc";
    }
  }

  copyTableToClipboard(): void {
    const headers = [
      "Name",
      "Class",
      "Spec",
      "Soft BiS",
      "Hard BiS",
      "Last Seen",
    ];
    const rows = this.filteredPlayers.map((player) => [
      player.name,
      player.class,
      player.spec || "",
      this.getSoftBisCount(player).toString(),
      this.getHardBisCount(player).toString(),
      new Date(player.lastSeen).toLocaleString(),
    ]);

    const allRows = [headers, ...rows];
    const colWidths = headers.map((_, i) =>
      Math.max(...allRows.map((row) => row[i].length))
    );

    const formatRow = (row: string[]) =>
      "| " + row.map((cell, i) => cell.padEnd(colWidths[i])).join(" | ") + " |";
    const divider =
      "+-" + colWidths.map((w) => "-".repeat(w)).join("-+-") + "-+";

    const tableLines = [
      divider,
      formatRow(headers),
      divider,
      ...rows.map(formatRow),
      divider,
    ];

    const tableString = tableLines.join("\n");

    navigator.clipboard.writeText(tableString).then(
      () => {
        this.copied = true;
        setTimeout(() => (this.copied = false), 3000);
      },
      (err) => {
        console.error("Failed to copy table:", err);
      }
    );
  }
}
