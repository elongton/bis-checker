import { Component, OnInit } from "@angular/core";
import { GearService } from "../gear.service";
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from "@angular/router";

interface Player {
  name: string;
  class: string;
  lastSeen: string;
  spec: string;
  items?: Record<string, Item[]>;
}

export interface Item {
  id: number;
  name: string;
}

@Component({
  selector: "app-bis-list",
  templateUrl: "./bis-list.component.html",
  styleUrl: "./bis-list.component.css",
})
export class BisListComponent implements OnInit {
  players: Player[] = [];
  gear: any | null = null;

  classFilter: string = "";
  nameSearch: string = "";
  sortColumn: "name" | "class" | "lastSeen" | "softBis" | "hardBis" = "name";
  sortDirection: "asc" | "desc" = "asc";
  selectedNames = new Set<string>();
  copied = false;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private gearService: GearService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.classFilter = params["class"] || "";
      this.nameSearch = params["name"] || "";
    });

    this.gearService.getLibrary().subscribe((lib) => {
      this.gear = lib;
      console.log(this.gear);
      this.loadPlayers();
      console.log(this.players);
    });
  }

  loadPlayers(): void {
    this.http.get<Player[]>("/api/player").subscribe({
      next: (data) => {
        this.players = data;
        console.log(data);
      },
      error: (err) => console.error("Failed to fetch players:", err),
    });
  }

  get filteredClasses(): string[] {
    const classes = new Set(this.players.map((p) => p.class));
    return Array.from(classes).sort();
  }

  get filteredPlayers(): Player[] {
    let filtered = this.players;

    if (this.classFilter) {
      filtered = filtered.filter(
        (p) => p.class.toLowerCase() === this.classFilter.toLowerCase()
      );
    }

    if (this.nameSearch.trim()) {
      const lowerName = this.nameSearch.toLowerCase();
      filtered = filtered.filter((p) =>
        p.name.toLowerCase().includes(lowerName)
      );
    }

    return filtered.sort((a, b) => {
      const aVal = this.getSortValue(a);
      const bVal = this.getSortValue(b);
      if (aVal < bVal) return this.sortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return this.sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }

  getSortValue(player: Player): any {
    switch (this.sortColumn) {
      case "lastSeen":
        return new Date(player.lastSeen).getTime();
      case "softBis":
        return this.getSoftBisCount(player);
      case "hardBis":
        return this.getHardBisCount(player);
      case "class":
        return player.class.toLowerCase();
      default:
        return player.name.toLowerCase();
    }
  }

  setSort(column: typeof this.sortColumn): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === "asc" ? "desc" : "asc";
    } else {
      this.sortColumn = column;
      this.sortDirection = "asc";
    }
  }

  getSpecOptionsForPlayer(player: Player): string[] {
    if (!this.gear) return [];
    const classGear = this.gear[player.class];
    return classGear ? Object.keys(classGear) : [];
  }

  updateSpec(player: Player, newSpec: string): void {
    this.http
      .patch(`/api/players/${encodeURIComponent(player.name)}/spec`, {
        spec: newSpec,
      })
      .subscribe({
        next: () => (player.spec = newSpec),
        error: (err) => console.error("Failed to update spec:", err),
      });
  }

  getSoftBisCount(player: Player): number {
    if (!player.spec || !this.gear) return 0;
    const specGear = this.gear[player.class]?.[player.spec];
    if (!specGear) return 0;
    let count = 0;
    for (const slot in specGear) {
      const playerItems = player.items?.[slot] || [];
      if (
        playerItems.some((item) =>
          specGear[slot].some((bis: Item) => bis.id === item.id)
        )
      ) {
        count++;
      }
    }
    return count;
  }

  getHardBisCount(player: Player): number {
    if (!player.spec || !this.gear) return 0;
    const specGear = this.gear[player.class]?.[player.spec];
    if (!specGear) return 0;
    let count = 0;
    for (const slot in specGear) {
      const topItem = specGear[slot][0];
      if (!topItem) continue;
      const playerItems = player.items?.[slot] || [];
      if (playerItems.some((item) => item.id === topItem.id)) {
        count++;
      }
    }
    return count;
  }

copyTableToClipboard(): void {
  const headers = [
    "Name",
    "Class",
    "Spec",
    "Soft BiS",
    "Hard BiS",
    "Last Seen",
  ];

  const source = [...this.filteredPlayers].filter(
    (p) => this.selectedNames.size === 0 || this.selectedNames.has(p.name)
  );

  const rows = source.map((player) => [
    player.name,
    player.class,
    player.spec || "",
    this.getSoftBisCount(player).toString(),
    this.getHardBisCount(player).toString(),
    new Date(player.lastSeen).toLocaleString(),
  ]);

  const allRows = [headers, ...rows];
  const colWidths = headers.map((_, i) =>
    Math.max(...allRows.map((row) => row[i].length))
  );

  const formatRow = (row: string[]) =>
    "| " + row.map((cell, i) => cell.padEnd(colWidths[i])).join(" | ") + " |";

  const divider =
    "+-" + colWidths.map((w) => "-".repeat(w)).join("-+-") + "-+";

  const tableLines = [
    divider,
    formatRow(headers),
    divider,
    ...rows.map(formatRow),
    divider,
  ];

  const tableString = tableLines.join("\n"); // ✅ Fix here

  navigator.clipboard.writeText(tableString).then(() => {
    this.copied = true;
    setTimeout(() => (this.copied = false), 3000);
  });
}

  updateQueryParams(): void {
    this.router.navigate([], {
      queryParams: {
        class: this.classFilter || null,
        name: this.nameSearch || null,
      },
      queryParamsHandling: "merge",
    });
  }

  toggleSelection(name: string): void {
    if (this.selectedNames.has(name)) {
      this.selectedNames.delete(name);
    } else {
      this.selectedNames.add(name);
    }
  }

  isSelected(name: string): boolean {
    return this.selectedNames.has(name);
  }

  areAllFilteredSelected(): boolean {
  return this.filteredPlayers.every(player => this.selectedNames.has(player.name));
}

toggleSelectAll(checked: boolean): void {
  if (checked) {
    for (const player of this.filteredPlayers) {
      this.selectedNames.add(player.name);
    }
  } else {
    this.selectedNames.clear(); // uncheck all, globally
  }
}
}
